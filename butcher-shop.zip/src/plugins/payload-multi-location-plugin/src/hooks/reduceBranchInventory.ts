import type { CollectionAfterChangeHook } from 'payload'

type RelationshipValue = number | string | { id?: number | string } | null | undefined

const getRelationshipId = (value: RelationshipValue) => {
  if (!value) return null
  if (typeof value === 'object') return value.id ?? null
  return value
}

export const reduceBranchInventory = (): CollectionAfterChangeHook => {
  return async ({ doc, operation, req }) => {
    if (operation !== 'create' && operation !== 'update') return doc
    if (doc.inventoryReduced) return doc

    const branchID = getRelationshipId(doc.fulfillment?.branch || doc.branch)
    const items = doc.items || doc.lineItems || []
    if (!branchID || !Array.isArray(items) || items.length === 0) return doc

    for (const item of items) {
      const productID = getRelationshipId(item.product || item.productID)
      const quantity = Number(item.quantity || 1)
      if (!productID || !Number.isFinite(quantity) || quantity <= 0) continue

      const inventory = await req.payload.find({
        collection: 'branch-inventory',
        depth: 0,
        limit: 1,
        where: {
          and: [
            { branch: { equals: branchID } },
            { product: { equals: productID } },
          ],
        },
      })

      const stock = inventory.docs[0] as any
      if (!stock?.manageStock) continue

      const nextQuantity = Math.max(0, Number(stock.stockQuantity || 0) - quantity)

      await req.payload.update({
        collection: 'branch-inventory',
        id: stock.id,
        data: {
          stockQuantity: nextQuantity,
          stockStatus: nextQuantity > 0 ? stock.stockStatus : 'outofstock',
        },
        overrideAccess: true,
      })
    }

    await req.payload.update({
      collection: 'orders',
      id: doc.id,
      data: {
        inventoryReduced: true,
      },
      overrideAccess: true,
    })

    return doc
  }
}