import Image from 'next/image'
import React from 'react'
import { getPayload } from 'payload'
import config from '@payload-config'

export const ProductGridBlock = async () => {
  const payload = await getPayload({ config })

  const products = await payload.find({
    collection: 'products',
    limit: 12,
  })

  return (
    <section className="bg-black text-white py-16">
      <div className="max-w-[1280px] mx-auto px-8 grid grid-cols-1 md:grid-cols-4 gap-10">

        {/* LEFT FILTER SIDEBAR */}
        <div className="space-y-10">
          <div>
            <h3 className="text-sm uppercase text-gray-400 mb-3">Cut Type</h3>
            {['Prime Rib', 'Wagyu Strips', 'Filet Mignon', 'Tomahawk'].map((item) => (
              <div key={item} className="text-sm text-gray-300">{item}</div>
            ))}
          </div>

          <div>
            <h3 className="text-sm uppercase text-gray-400 mb-3">Aging</h3>
            {['21 Days Dry-Aged', '45 Days Dry-Aged', 'Wet-Aged Prime'].map((item) => (
              <div key={item} className="text-sm text-gray-300">{item}</div>
            ))}
          </div>

          <div>
            <h3 className="text-sm uppercase text-gray-400 mb-3">Origin</h3>
            {['Japanese Miyazaki', 'Australian Wagyu', 'Heritage Angus'].map((item) => (
              <div key={item} className="text-sm text-gray-300">{item}</div>
            ))}
          </div>
        </div>

        {/* RIGHT CONTENT */}
        <div className="md:col-span-3">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-2xl uppercase">The Shop</h2>
              <p className="text-gray-400 text-sm">
                Curated selections of the world's finest prime cuts.
              </p>
            </div>

            <div className="text-sm text-gray-400">
              SORT BY: <span className="text-yellow-400">RECOMMENDED</span>
            </div>
          </div>

          {/* PRODUCT GRID */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {products.docs.map((product) => (
              <div key={product.id} className="bg-[#121414] border border-white/5">

                {/* IMAGE */}
                <div className="relative h-[300px]">
                  {product.image?.url && (
                    <Image
                      src={product.image.url}
                      alt={product.name}
                      fill
                      className="object-cover"
                    />
                  )}

                  {product.tag && (
                    <span className="absolute top-3 left-3 bg-black px-2 py-1 text-xs text-yellow-400">
                      {product.tag}
                    </span>
                  )}
                </div>

                {/* CONTENT */}
                <div className="p-6">
                  <div className="flex justify-between">
                    <h3 className="text-lg">{product.name}</h3>
                    <span className="text-yellow-400">${product.price}</span>
                  </div>

                  <p className="text-xs text-gray-400 mt-1">
                    {product.origin} • {product.aging}
                  </p>

                  <p className="text-sm text-gray-500 mt-3">
                    {product.description}
                  </p>

                  <button className="mt-6 w-full bg-yellow-500 text-black py-3 uppercase text-sm">
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  )
}